-- DROP TABLE Employee;
-- DROP TABLE Tax;
-- CREATE TABLE Employee (ssn CHAR(12) PRIMARY KEY NOT NULL, fName CHAR(36) NOT NULL, lName CHAR(36) NOT NULL, position CHAR(36) NOT NULL, dependents INT DEFAULT 0, annualsalary FLOAT DEFAULT 0.0);
-- CREATE TABLE Tax (ssn CHAR(12) PRIMARY KEY NOT NULL, incometax FLOAT NOT NULL DEFAULT 0.0);

-- INSERT INTO Employee (ssn, fName, lName, position, dependents, annualsalary) VALUES ('333-22-3313', 'Mason', 'Greenwood', 'developer', 0, 90000.00);
-- INSERT INTO Employee (ssn, fName, lName, position, dependents, annualsalary) VALUES ('333-22-9293', 'Danny', 'Welbeck', 'sr. developer', 2, 100000.0);
-- INSERT INTO Employee (ssn, fName, lName, position, dependents, annualsalary) VALUES ('333-22-1111', 'Ole', 'Gunnar', 'manager', 3, 180000.0);
-- INSERT INTO Employee (ssn, fName, lName, position, dependents, annualsalary) VALUES ('333-22-0933', 'Tony', 'Martial', 'sr. admin', 4, 250000.0);
-- INSERT INTO Employee (ssn, fName, lName, position, dependents, annualsalary) VALUES ('333-22-0999', 'Harry', 'Magure', 'principa', 2, 280000.0);

CREATE PROCEDURE Compute_Tax
AS 
BEGIN 
    SET NOCOUNT ON;
    DECLARE @netSalary TABLE(ssn CHAR(36), netsalary FLOAT)
    
    INSERT INTO @netSalary SELECT Employee.ssn, Employee.annualsalary - (7000 + (Employee.dependents * 950)) FROM Employee 
    INSERT INTO Tax SELECT ssn, 
        CASE
            WHEN netsalary<= 15000 THEN netsalary*.10
            WHEN netsalary>15000 AND netsalary <= 30000 THEN netsalary * .15
            ELSE netsalary * .30
        END
        FROM @netSalary
    END
go

