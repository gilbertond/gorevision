
CREATE PROCEDURE Factorial (@num INT) AS
BEGIN
DECLARE @fact bigint
SET @fact = 1

IF(@num<0)
    BEGIN
        PRINT 'Negative number'
        RETURN
    END
ELSE 
    IF(@num = 0)
        BEGIN
            SET  @fact = 1
        END
    ELSE
        BEGIN
            WHILE(@num >0)
                BEGIN
                    SET @fact = @fact * @num
                    SET @num = @num -1
                END
        END
PRINT @fact    
END
go

